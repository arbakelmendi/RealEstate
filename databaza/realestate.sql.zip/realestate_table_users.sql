
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` text NOT NULL,
  `pw` text NOT NULL,
  `status` text NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `pw`, `status`, `id`) VALUES
('olis', '$2y$10$FUbv7gaq4fzcSr3xaX7Uie2YaUG7B/1GCJkuHAbBRu2AZLmt7T29q', 'admin', 3),
('arba', '$2y$10$s6YHqhiez/kl4y8.ArSXAuDl26zpR5v9wxh6mjVDcy/0/Eb8lZKUi', 'admin', 4);
